Mi Ciudad 3D - proyecto Android (WebView)
=========================================

IMPORTANTE: este ZIP es el proyecto fuente, NO es un APK ya compilado.

Para generar el APK:
1. En una computadora, instala Android Studio desde la web oficial de Android Developers.
2. Abre Android Studio y elige Open; selecciona la carpeta MiCiudad3D_Android.
3. Espera a que termine Gradle Sync.
4. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio mostrará dónde quedó el APK.

El juego carga Three.js desde un CDN, por lo que necesita internet para iniciar.
